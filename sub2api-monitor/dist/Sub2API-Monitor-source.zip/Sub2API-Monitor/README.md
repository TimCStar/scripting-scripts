# Sub2API 用量看板 · iOS Scripting

一个不依赖第三方中转服务的中文主屏幕小组件与手动重置面板。单一整面背景、文字和进度条使用黑白灰，适配浅色/深色；只有真实品牌图标保留原始颜色。默认首先显示标明「演示 · 虚构数据」的示例，不会联网。

版本：1.1.1。小组件只保留真实平台图标、账号显示名称和额度；不显示平台文字、标题、采样时间、ID、分组或今日统计。

## 安装与配置

1. iPhone 安装 **Scripting**。将 `Sub2API-Monitor.scripting` 用「分享 → Scripting」打开并导入。`.scripting` 是根目录含 `script.json`、`index.tsx`、`widget.tsx` 的 ZIP 包。若系统没有自动识别，在 Scripting 的导入入口选择文件。也可在 app 新建项目，复制源码目录的全部 `.ts` / `.tsx` 文件及完整 `assets/` 目录。
2. 在 Scripting 中运行「Sub2API 用量看板」。填写服务器 HTTPS 地址，例如 `https://sub.example.com`。若部署于子路径，可填 `https://example.com/sub2api`；末尾 `/api/v1` 会自动移除。
3. 填写 Sub2API **上游账号**的数字 ID，以逗号分隔。顺序就是显示顺序，例如 `12,34,56,78`。最多配置 12 个。可以在管理后台查看账号 ID。
4. 选择管理员 API Key（`x-api-key`）或管理员 JWT（`Authorization: Bearer`），在安全输入框粘贴。这里需要管理员权限；普通下游转发 Key、普通用户登录 JWT 不适用。JWT 过期后需要手动更新。本工具不自动登录或刷新凭证。
5. 每个账号有独立「显示名称」输入框，留空沿用服务器名称；「5h 显示」可选自动、显示或隐藏。Pro 账号没有该窗口时可选择隐藏，不会按套餐名称一刀切。可先点「测试连接（只读）」，成功后点「保存并启用真实数据」。测试只检查前四个账号，不会保存凭证。保存会清除缓存并请求小组件刷新。
6. 长按主屏幕添加 Scripting 小组件，选择本脚本。小号显示 1 个账号，中号可选 1–2 个，大号可选 1–4 个。可在脚本内分别预览，并切换账号数量选项。
7. 可选：在小组件 Parameter 填已配置的账号 ID，例如 `34` 或 `56,12`，以单独选择/排序及设置数量。中号填 `34` 显示 1 个放大账号，填 `34,12` 显示 2 个；大号可填 1–4 个 ID。参数不得含凭证、URL 或 JSON。未知 ID 或超过此尺寸容量会显示错误，而不会悄悄截断或换账号。留空使用全局配置顺序的前 1 / 2 / 4 个。演示模式可选 101、102、103、104，例如 `101` 看放大 Codex，`101,102` 看双账号。

### 升级与账号设置

导入新包可能创建新的脚本项目。凭证及设置按脚本作用域保存，不能保证跨新项目保留；若创建新项目，请重新填写服务器、账号 ID 与凭证。请勿先删除旧项目；删除脚本可能删除其钥匙串项。安装包不包含个人设置或凭证。

### 1.1.1 显示修正与确认

- 根容器使用官方示例的 `frame={Widget.displaySize}`，按实际宿主尺寸铺满整面背景；无内层卡片色块。外层不设 padding，内容间距独立放在内层（小号 14pt，其他 12pt）。没有硬编码某款 iPhone 的尺寸，也没有调用未文档化的 widget 边距开关。
- 每个显示的额度窗口都显示绝对重置时间，格式 `M/D HH:mm`，采用设备本地时间。仅显示时间，不加「下次重置」说明；未知显示 `—`，不会因小号或紧凑布局隐藏。
- 图标先从 `provider-artwork.ts` 内嵌的原始 PNG 字节同步解码为 `UIImage`，完成后才调用 `Widget.present`；无需等待图片视图读取路径。如果解码失败，才尝试相同的本地 PNG 文件。两种模式都成功才传给 `Image.image`，不以假图标代替。
- 配置页「预览 · v1.1.1」显示版本、3 个图标及解码结果。版本与诊断不放进小组件。更新后先确认版本，再检查三种尺寸的实际主屏幕显示；新建了脚本项目时需把小组件重新指向新项目。
- 旧版的 `Image.filePath` 写法本身属于官方支持 API；本次修改去除对运行时资源路径的依赖，并不能证明设备上缺图只有这一种原因。尚未在真实 iPhone 复测黑边与图标问题。

### 自适应信息密度

- 小号 1 个账号；中号 1 个账号时放大双栏，2 个账号时并排紧凑卡。
- 大号 1 个账号时放大，2 个账号时双扩展卡，3–4 个账号时紧凑多行。
- 每张卡只显示离线真实平台图标、账号别名和额度。窗口进度下方的 7d 金额是「已用 USD / 估算总 USD」；小组件不堆叠解释文字。
- 每个窗口始终显示绝对重置时间。有空间时另显示缓存重置券，以及打开应用确认面板的「重置…」。链接本身不会提交重置。演示账号不能执行重置。
- 自定义名称及 5h 显示选择仅保存本机，不修改服务器账号。显示名称最长 40 字；短别名更适合紧凑布局。

## 看板里每个数字的含义

- **已用 %**：读取 OpenAI `codex_5h_*` / `codex_7d_*` 或 Claude 被动快照。Claude 的 0–1 比例换算成百分比。真实 0% 是正常数值；没有测量值显示未知，绝不伪造 0%。允许文字超过 100%，条形仅在绘制时封顶。
- **没有 5h 与未知**：OpenAI 没有观察到 5h 字段时，自动模式省略该行；这不等于已证明无限额。有真实窗口时即使 0% 仍正常显示。可按账号选择隐藏；强制显示但无数据时显示未知。不会凭 Pro 名称判断所有账号的限制。
- **7d 金额**：OpenAI / Claude 以当前快照重置时间减去 7 天为窗口起点，从 Sub2API 本地记录累计账号口径费用；完整 UTC 日期由 `/admin/usage/stats` 汇总，首个非完整日期由 `/admin/usage` 分页日志按实际起点过滤。金额口径含账号倍率。总额按 `已用费用 × 100 / 原生已用百分比` 自动估算，与上游管理面板公式一致。
- **估算的边界**：分母不是服务商承诺的余额或美元限额。其他实例产生的使用可能影响原生百分比，却不在本实例账单中；采样延迟及比例取整也会影响估算。不是今日费用或任意最近 7 天，更不是手动参考额度或剩余比例。
- **未知金额**：比例/费用为 0 时无法反推总额，总额显示 `—`；窗口、记录、时区、刷新状态或分页完整性无法确认时不伪造金额。首日超过 2,000 条记录会保守显示未知。比例快照旧时保留可核验的窗口已用费用，但不反推总额；已过期窗口不显示美元值。
- **Claude / Antigravity**：Claude 显示原生百分比；只有能确认 7d 重置点及完整本地费用时才显示相应金额。Antigravity 没有可安全读取的持久化额度快照时显示「暂无额度快照」，不把按模型余额包装成 5h/7d。
- **旧快照**：只用中性文字表示旧数据或待更新，0% 和旧快照本身不触发黄色/红色警告。真实连接或账号异常另行提示。没有采样时间标签，也没有顶部刷新时间。
- **平台图标**：使用随包携带并内嵌于源码的真实品牌 PNG，先离线解码，适配浅/深背景。来源、商标说明和第三方图标代码许可证见 `assets/ATTRIBUTION.md`；不使用 SF Symbols 替代品牌标志。

账号之间的百分比不会相加，多分组账号不会重复计费。旧版手动参考额度不再用于显示。

**配置仅在当前脚本 Storage，凭证仅在本机 Keychain。** 不要分享设备存储备份、真实凭证或敏感账号截图。管理凭证具有较大权限，请只在可信设备使用。

## 安全与请求边界

小组件刷新和读取账号只请求以下 GET，且拒绝重定向：

- `/api/v1/admin/accounts/:id`
- `/api/v1/admin/usage/stats?account_id=…&start_date=…&end_date=…&timezone=UTC&nocache=true`
- `/api/v1/admin/usage?account_id=…&start_date=…&end_date=…&timezone=UTC&exact_total=true&sort_by=id&sort_order=asc&page_size=500&page=…`

后两项只读取本实例记录，不是 `/accounts/:id/usage` 上游探测入口。原始日志不写入缓存，只保留核验后的金额。

小组件不会调用模型、消耗推理 token、探测 Responses、刷新登录态、提交修改或触发额度重置。特意不使用通用 `/accounts/:id/usage`、批量 usage、OpenAI `/quota`：当前上游这些入口可能探测模型、清除账号异常或触发已配置的重置行为。Antigravity 的兼容 five_hour 字段也不代表真正 5 小时额度。

### 手动 Codex 重置：明确确认，一次请求

1. 先保存真实服务器设置。展开卡点「重置…」，或直接打开脚本的「Codex 重置中心」。链接中的账号 ID 仅为选择提示，绝不是批准。
2. 点「读取账号与重置券（只读）」。仅 OpenAI OAuth 主账号提供操作按钮；其他平台、API Key 账号和 Spark 影子账号不支持。缓存的券数不是实时资格承诺。
3. 点对应账号「核对并重置一次…」。应用重新 GET 账号详情，再显示明确的确认框：服务器、账号名/ID、缓存券数，**不可撤销地消耗 1 次 Codex 重置券**，可能恢复账号限流状态并刷新缓存。不能选择只清 5h 或只清 7d；实际重置窗口由服务端返回。
4. 只有点「消耗 1 次并重置」才执行。确认后再检查一次账号身份/类型。先把 pending 收据同步写入本机 Keychain 并读回验证，随后向你配置的 Sub2API 发送**一次** `POST /api/v1/admin/openai/accounts/:id/reset-quota`，无请求体，无窗口选择参数，无自动重试。所有上游交互由你的 Sub2API 服务器处理；脚本不直接连接 OpenAI。
5. 成功显示重置窗口数。即使缓存刷新/账号恢复部分失败，也明确表示重置已完成，不能再次点击来「修复」。超时、连接中断、5xx、格式不明都显示「结果不确定」，并保留本机防重复锁；券可能已经消耗。
6. 到管理后台核对实际结果。只有你确认「已核对，解除本机锁」，才允许以后发起新的确认；解除本机锁本身不发网络请求。成功操作也保留锁，防止误连点。

收据按服务器地址和账号 ID 绑定，换凭证/重新保存配置不会自动解除；移除管理凭证不会删除这些防重复收据。操作中的同步本机锁与 pending 收据可防止当前进程重复点击和常见重启重试，但**服务端不提供客户端幂等键**。不要在多个设备或多个独立运行实例同时操作同一账号；本工具无法提供跨设备锁或保证异常退出后的 exactly-once。

本版本只实现及模拟验证这个功能，未连接真实账号、未消耗任何实际重置券。不可把安装或小组件链接当作一次真实操作的批准。

管理员凭证只存设备专用、首次解锁后可访问的钥匙串项（`first_unlock_this_device`、不做 iCloud 同步），不会进入脚本源码、URL、小组件参数、普通配置、缓存、日志或安装包。网络异常不回显原始服务端响应。服务端详情响应可能包含敏感字段；只有白名单显示字段被归一化并缓存，原始账号对象不落盘。

重启后尚未首次解锁、钥匙串读取失败、401/403、离线和服务端错误都会降级为缓存或设置提示。不支持 HTTP、自签名证书绕过、URL 里的用户名密码或查询参数。不跟随重定向，避免把管理凭证发到其他地址。

「移除本机凭证和缓存」会切到演示模式。删除脚本也会删除脚本作用域内钥匙串项。新服务器必须重新输入凭证，不能沿用旧服务器的凭证。

## 刷新与兼容范围

默认请求约 20 分钟后刷新；iOS 自行决定真正刷新时间，不能保证准点或后台常驻。缓存减少重复请求。每次最多并行读取当前小组件可见的 1 / 2 / 4 个账号，小组件单请求超时 8 秒（应用内账号核对 12 秒，手动重置 45 秒）。失败保留每个账号的最后成功数据；不同尺寸/参数共享白名单缓存但独立检查所选账号的更新时间。

已依据 **Wei-Shaw/sub2api v0.2.15，commit `3a6fd1c9db07203ca308aaba69e502bc1f35b307`（2026-10-09）** 验证字段。兼容部署差异时采用「未提供」，不虚构数据。旧版没有当前 canonical Codex 字段时不推测 legacy primary/secondary 的意义。未配置或未观察到快照时，可通过正常业务使用让服务端自然采样，再等系统刷新；脚本不会主动制造使用量。

小组件的着色/强调模式由 iOS 管理：根背景使用 `widgetBackground`，会在该模式隐藏；图标设置 `widgetAccentedRenderingMode="fullColor"` 保留真实颜色。支持 standard systemSmall / systemMedium / systemLarge，锁屏/accessory family 未作适配。

## 验证记录与限制

- 已运行 Node 24 原生 TypeScript 去类型化下的纯数据与模拟网络测试：HTTPS 校验、ID 顺序、0/未知/超额、窗口时长、相对重置锚点、Claude 比例、缓存字段白名单、Antigravity 不支持、自动窗口金额估算与不完整分页降级、重定向拒绝、401 保留缓存、统计部分失败、账号错配、自适应账号选择、手动重置防重复、未确认/不匹配/过期时拒绝、超时不重试、部分成功、收据失败等。
- TypeScript 5.9.3 严格检查纯数据层 `model.ts` / `client.ts` / `operations.ts` / `display.ts` / `provider-images.ts` / `provider-artwork.ts`，并对全部 TS/TSX 做语法转译检查；不使用伪造的 Scripting 类型声明冒充 API 类型检查。
- 67 个纯逻辑/模拟网络/图标测试通过，另有 13 个模拟 Scripting 桥接的 TSX 视图树检查，覆盖全部账号数量、图标回退/失败、错误状态及双窗口旧快照的紧凑布局。视图树检查不测量 SwiftUI 像素，不是设备渲染验证。
- Scripting 组件/API 对照官方文档审查；安装格式对照官方 `.scripting` ZIP 示例。
- **未在真实 iPhone / Scripting 运行测试，未连接真实 Sub2API 服务器，未获得当前设备同步的官方 `scripting.d.ts` 做 API 类型检查。** 模拟测试通过不代表 iOS 布局已经设备验证。可在 app 预览三种尺寸，若账号名较长，可改为短别名或减少显示账号数量。

开发者运行：`npm test`（Node 22.6+，推荐 Node 24）。没有 npm 运行时依赖。可选 `npm install` 后执行 `npm run typecheck:core` 、`npm run check:syntax` 与 `npm run check:render`；TypeScript 仅为开发依赖。测试会在临时目录复制纯数据模块并调整本地扩展名，不改发布源码。

### 官方参考

- [Sub2API 固定版本源码](https://github.com/Wei-Shaw/sub2api/tree/3a6fd1c9db07203ca308aaba69e502bc1f35b307)
- [Scripting Widget API](https://scriptingapp.github.io/guide/Widget/Widget%20API)
- [Scripting UIImage](https://scriptingapp.github.io/guide/Utilities/UIImage)
- [Scripting Image](https://scriptingapp.github.io/guide/Views/Image/)
- [Scripting frame](https://scriptingapp.github.io/guide/View%20Modifiers/frame)
- [Scripting 着色模式](https://scriptingapp.github.io/guide/Widget/Tinted%20Mode%20Adaptation%20Guide)
- [Scripting Keychain](https://scriptingapp.github.io/guide/Device%20Capabilities/Keychain)
- [Scripting fetch](https://scriptingapp.github.io/guide/Utilities/Request/fetch)
- [Scripting 官方打包示例](https://github.com/ScriptingApp/Community-Scripts/blob/main/Widget%20Animation%20Demo.scripting)
- [Apple Widget 刷新说明](https://developer.apple.com/documentation/widgetkit/keeping-a-widget-up-to-date/)
